
package com.info.email.repository;
import com.info.email.model.mensagem;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MensagemRepository extends JpaRepository<mensagem, String> {
    Optional<mensagem> findByLogin(String login);
    boolean existsByLogin(String login);
}
