package com.info.email.repository;

import com.info.email.model.Mensagem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MensagemRepository extends JpaRepository<Mensagem, Integer> {
    
    // Busca as mensagens onde o destinatario seja igual ao login do usuario logado
    List<Mensagem> findByDestinatario(String destinatario);
}