
package com.info.email.repository;
import com.info.email.model.usuario;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<usuario, String> {
    Optional<usuario> findByLogin(String login);
    boolean existsByLogin(String login);
}
