package com.info.email.controller;

import com.info.email.model.Mensagem;
import com.info.email.model.Usuario;
import com.info.email.repository.MensagemRepository;
import com.info.email.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
public class LoginController {

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private MensagemRepository mensagemRepository; // Injetando o repositório de mensagens

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/redirecionar")
    public String redirecionar(Authentication auth) {
        Usuario usuario = repository.findByLogin(auth.getName()).orElse(null);
        if (usuario != null && usuario.getTipo() == 1) {
            return "redirect:/usuarios";
        }
        return "redirect:/mensagens";
    }
    
    @GetMapping("/usuarios")
    public String listarUsuarios() {
        return "usuarios"; 
    }

    // LISTAR MENSAGENS RECEBIDAS
    @GetMapping("/mensagens")
    public String caixaDeEntrada(Authentication auth, Model model) {
        String logado = auth.getName();
        
        // Busca no banco as mensagens enviadas para o usuário atual
        List<Mensagem> mensagensRecebidas = mensagemRepository.findByDestinatario(logado);
        
        model.addAttribute("username", logado);
        model.addAttribute("mensagens", mensagensRecebidas); // Envia a lista para o HTML
        return "mensagens";
    }

    @GetMapping("/mensagens/nova")
    public String escreverMensagem(Authentication auth, Model model) {
        model.addAttribute("username", auth.getName());
        return "escrever";
    }

    // PROCESSAR O ENVIO DO FORMULÁRIO (SALVAR NO BANCO)
    @PostMapping("/mensagens/enviar")
    public String enviarMensagem(
            Authentication auth,
            @RequestParam("destinatario") String destinatario,
            @RequestParam("assunto") String assunto,
            @RequestParam("conteudo") String conteudo) {
        
        Mensagem novaMensagem = new Mensagem();
        novaMensagem.setRemetente(auth.getName()); // O remetente sempre será o usuário logado
        novaMensagem.setDestinatario(destinatario);
        novaMensagem.setAssunto(assunto);
        novaMensagem.setData(LocalDate.now()); // Salva automaticamente com a data de hoje
        novaMensagem.setMsg(conteudo);
        
        mensagemRepository.save(novaMensagem); // Salva no banco de dados!
        
        return "redirect:/mensagens"; // Redireciona de volta para a Caixa de Entrada
    }
}